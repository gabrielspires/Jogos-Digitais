Artwork created by Luis Zuno (@ansimuz)

Contents

/Background 
Contains the tile background and transparent clouds in PNG format

/Spritesheets
This contains all the ships and elements animated in PNG files

/PSD
In case you need to modify the graphics i included a working PSD (Photoshop Document) file 

Get more resources at ansimuz.com

